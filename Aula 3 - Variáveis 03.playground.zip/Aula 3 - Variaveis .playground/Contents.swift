//Variaveis

//let name: Strig = "Arthur"
//let idade: Int = "19"
//let sexo: String = "M ou F"

// IF - ELSE

let name: String = "Arthur"

if name == "Arthur" {
    print("Seu nome é Arthur")
}else {
    print("Seu nome não é Arthur")
}

if name == "Arthur" || name == "João" || name == "Natan" {
    print("Seu nome é \(name)")
}else {
    print("Seu nome não está registrado")
}

