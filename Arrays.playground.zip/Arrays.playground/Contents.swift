//var list: [String] = ["Arroz", "Feijão", "Milho", "Carne", "Suco"]
//
//print(list)
//// Selecionar
//print(list[2])
//// Alterar
//list[3] = "Frango"
//print(list)
////Contar
//print(list.count)
////Inserir
//list.append("Sabonete")
//list.insert("Sabonete", at: 2)
//print(list)
////Remover
//let oldItem = list.remove(at: 2)
//list.removeAll(where: { $0 == "Feijão" })
////Highorders (Filtro)
//let filteredList = list.filter({ $0 == "Feijão" })
//
//print(list)
//print(oldItem)
//print(filteredList)

//Criar uma lista de algum tipo de itens (minimo 10)
//Adicionar um novo elemento a essa lista
//Remover o elemento 4
//Adicionar na posição 3
//Alterar 2 elementos

var list2: [String] = ["Monopoly Poker", "Mad Max", "Sea of Thieves", "Terraria", "God of War",
                       "Warframe", "Cliker Heroes", "CS 2", "Destiny 2", "Paladins", "Neverwinter"]
print(list2)

//Adicionar Elemento
list2.append("Hollow Knight")
list2.insert("Hollow Knight", at: 3)
print(list2)

//Remover Elemento
let oldItem = list2.remove(at: 4)
print(list2)

//Adicionar na Posição







