// 1 - Consider the following code snippet.
let myConstant = Int("7")
//What will the type of myConstant be?

// a) Int? X
// b) Int
// c) String
// d) Double

// 2 - Review the code and identify what will be printed to the console.
var needsUpdate = false
var forceUpdate = true
if needsUpdate || forceUpdate {
    print("Updating system...")
} else if forceUpdate {
    print("Force updating the system...")
} else {
    print("No updates.")
}
// a) Nothing
// b) "Updating system..." X
// c) "Force updating the system..." 
// d) "No updates."
