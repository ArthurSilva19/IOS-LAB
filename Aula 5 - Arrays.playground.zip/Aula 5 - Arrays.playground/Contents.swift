//let list: [String] = ["Arroz", "Feijão", "Milho", "Carne", "Suco"]
var list: [String] = ["Arroz", "Feijão", "Milho", "Carne", "Suco"]

print (list)
print (list[2])

print (list.count)
//list.append("Sabonete")
print(list)

list.insert("Sabonete", at: [2])
print(list)

list.remove(at: [2])
print(list)
